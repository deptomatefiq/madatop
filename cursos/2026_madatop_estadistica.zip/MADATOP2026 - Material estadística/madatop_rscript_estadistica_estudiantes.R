# FIQ-UNL - Escuela MADATOP
# Módulo de Estadística

########## Bootstrap - ejemplos prácticos #############

# Cargamos algunas librerías
library(tidyverse)
library(plotly)

#######################################################

# Simulando datos poblacionales
set.seed(123) # fijamos una semilla para reproducibilidad
mu = 33
sigma = 3
tamanio = 10000000
poblacion = rnorm(tamanio, mu, sigma)
hist(poblacion, freq = F, main = "Datos poblacionales", xlab = "X")
plot(density(poblacion))
mean(poblacion)

nreps = 1000
n = 100
medias.muestrales = NULL

for (i in 1:nreps){
  medias.muestrales[i] = mean(sample(poblacion, n, replace = F))
}

# Distribución de la media muestral
hist(medias.muestrales, freq=F, main = "Distribución muestral de Xbarra", xlab = "Xbarra", xlim = c(32,34))
abline(v = mu, col = "red", lwd = 2)


### EJERCICIO 1 ###
mean(...)
sd(...)

n = ...
medias.muestrales = NULL

for (i in 1:nreps){
  medias.muestrales[i] = mean(sample(poblacion, n, replace = F))
}


#######################################################

# Ejemplo 1 
# datos simulados, caso real
# No tengo los datos de la poblacion, sino que tengo una muestra aleatoria

muestra = sample(poblacion, n, replace = F)

# puedo calcular la media muestral
mean(muestra)

# IC bajo normalidad (planteo un supuesto y una teoría)
alfa = 0.05
z = qnorm(1-alfa/2)
Li = mean(muestra) - z*sd(muestra)/sqrt(n)
Ls = mean(muestra) + z*sd(muestra)/sqrt(n)

# Podemos estudiar la variabilidad del estimador por bootstrap?
nreps = 5000
medias.boot = NULL

for (i in 1:nreps){
  medias.boot[i] = mean(sample(muestra, n, replace = T))
}

hist(medias.boot, freq = F, main = "Distribución bootstrap", xlab = "medias bootstrap") # a quién se parece?
abline(v = mean(muestra), col = "red")

plot(ecdf(medias.boot), main = "Distribución acumulada boot (empírica)", xlab = "medias bootstrap", ylab = "Ghat_boot(x)")

mean(medias.boot)
sd(medias.boot)

# Intervalos
# Teoría normal

round(c(Li, Ls),2)

# Intervalos boot
# Regla del 95%

round(c(mean(muestra)-2*sd(medias.boot), mean(muestra)+2*sd(medias.boot)),2)

# Intervalo percentílico

round(quantile(medias.boot, c(0.025, 0.975)),2)

# Qué representa el intervalo? cómo puedo "medir" de alguna 
# manera su "confianza"? 
# esto no se puede hacer con datos reales, pero puede servir 
# para estudiar/validar qué tan bien estamos estimando la variabilidad

# Loop 1 (generar una nueva muestra aleatoria)
for(i in 1:M){
  
  # Generar muestra
  x = rnorm(n, mean = mu, sd = sigma)
  
  # Estadísticos
  xbar = mean(x)
  s = sd(x)
  
  xboot = numeric(B)
  
  # Loop 2 (realizar bootstrap sobre la muestra actual)
  for(j in 1:B){
    xboot[j] = mean(sample(x, n, replace = T))
  }
  
  # Intervalo de confianza (normal)
  tcrit = qt(1 - alfa/2, df = n - 1)
  LI_n = xbar - tcrit * s / sqrt(n)
  LS_n = xbar + tcrit * s / sqrt(n)
  
  # Intervalo de confianza (bootstrap)
  intervalo = quantile(xboot, c(0.025, 0.975))
  LI_b = intervalo[1]
  LS_b = intervalo[2]
  
  # Verificar si contiene la media verdadera
  coverN[i] = (LI_n <= mu & mu <= LS_n)
  coverB[i] = (LI_b <= mu & mu <= LS_b)
  
}

# Coverage empírico
mean(coverN)
mean(coverB)

#######################################################

# Ejemplo 2

### EJERCICIO 2 ###
library(eph)
df = eph::get_microdata(year = 2025, period = 3, type = "individual")
edad = df$CH06

# Análisis exploratorio de la variable edad
mean(edad)
sd(edad)
hist(edad, freq = FALSE, main = "Distribución de la variable edad")


n = ...
nreps = 5000
medias = NULL

for (i in 1:...){
  medias[i] = mean(...(..., ..., ...))
}

hist(..., freq = F) 

mean(...)
sd(...)

# IC bajo normalidad
alfa = 0.05
z = qnorm(1-alfa/2)

ICnorm = c(mean(edad)-z*sd(...)/sqrt(n), mean(...)+z*sd(...)/sqrt(n))

# IC bootstrap
ICBoot = c(mean(edad)-2*sd(...), mean(...)+2*sd(...))



#######################################################

# Ejemplo 3 - bootstrap aplicado a modelos estadísticos

# A) Regresión lineal simple

set.seed(123)
n = 100
beta0 = 2
beta1 = 3
sigma = 1

# Datos de entrenamiento
x = runif(n, 0, 10)
y = beta0 + beta1*x + rnorm(n, 0, sigma)

# Dato de predicción
x0 = 6

mod = lm(y ~ x)

plot(x, y)
abline(mod, col = "blue", lwd = 1.5)
points(x0, predict(mod, newdata = data.frame(x = x0)), col = "red", pch = 16)

# Varianza teórica/normal de beta1
varbeta1.norm = round(summary(mod)$coefficients["x", "Std. Error"]^2,4)

# IC clásico para respuesta media y0
IC_clasico = predict(mod, newdata = data.frame(x = x0),
                     interval = "confidence",
                     level = 0.95)

# Bootstrap para var(beta) y var(y0)
B = 5000
beta1_boot = numeric(B)
yhat_boot = numeric(B)

for(b in 1:B){
  ind = sample(1:n, size = n, replace = TRUE)
  x_b = x[ind]
  y_b = y[ind]
  mod_b = lm(y_b ~ x_b)
  beta1_boot[b] = coef(mod_b)[2]
  yhat_boot[b] = predict(mod_b, newdata = data.frame(x_b = x0))
}

# Distribuciones bootstrap
hist(beta1_boot, freq = F, main = "beta1 boot")
hist(yhat_boot, freq = F, main = "y0 boot")

# var e IC bootstrap
varbeta1.boot = round(var(beta1_boot), 4)
IC_boot = quantile(yhat_boot, c(0.025, 0.975))

# Comparación
round(varbeta1.norm, 4)
round(varbeta1.boot, 4)

round(IC_clasico, 3)
round(IC_boot, 3)


# B) Regresión lineal múltiple
datos = read.table("vino.txt", header = TRUE, sep = "")
datos = datos[,-1]
datos$Region = as.factor(datos$Region)
dato_prueba = datos[5, ]
datos = datos[-5, ]
pairs(datos)

modelo = lm(Calidad ~ Cuerpo + Sabor + Fuerza, data = datos)
summary(modelo)
plot(modelo)
pred_puntual = predict(modelo, dato_prueba, se.fit = TRUE, interval = "confidence")

x1 = seq(from = min(datos$Calidad),to = max(datos$Calidad),by = 0.1)
rectaunidad = x1

ggplot() +
  geom_point(aes(x = datos$Calidad, y = modelo$fitted.values),col = 'blue') +
  geom_line(aes(x = x1, y = rectaunidad),col='black',size=1) +
  labs(title = "Predicho vs nominal") +
  theme_bw()

# Bootstrap
m = 5000 
n = nrow(datos)
betas = matrix(0, ncol = 4, nrow = m)
pred_puntual_boot = matrix(NA, nrow = m, ncol = 1)

for (i in 1:m){
  train_idxs = sample(1:n, size = n, replace = TRUE)
  datosB = datos[train_idxs,]
  fit_boot = lm(Calidad ~ Cuerpo + Sabor + Fuerza, data = datosB) 
  betas[i,] = fit_boot$coefficients[1:4]
  pred_puntual_boot[i] = predict(fit_boot, dato_prueba)
}

# Distrib bootstrap de beta y de y0
hist(betas[,1], freq = F, main = "Beta0")
hist(betas[,2], freq = F, main = "Beta1")
hist(betas[,3], freq = F, main = "Beta2")
hist(betas[,4], freq = F, main = "Beta3")

hist(pred_puntual_boot, freq = F)

# Error estándar de los beta estimados
resumen = summary(modelo)
sebetas_teor = as.numeric(resumen[["coefficients"]][,2])

sdbeta1 = sd(betas[,1])
sdbeta2 = sd(betas[,2])
sdbeta3 = sd(betas[,3])
sdbeta4 = sd(betas[,4])

# Error estándar de la predicción
sdteor = pred_puntual$se.fit
sdpred = sd(pred_puntual_boot)

# Comparación
SDs1 = data.frame(
  Cantidad = c("Predicción", "SE predicción"),
  Teoría = c(pred_puntual$fit[1], sdteor),
  Bootstrap = c(mean(pred_puntual_boot), sdpred)
)

SDs2 = data.frame(
  Cantidad = c("beta1", "SE beta1",
               "beta2", "SE beta2",
               "beta3", "SE beta3",
               "beta4", "SE beta4"),
  
  Teoría = c(coef(modelo)[1], sebetas_teor[1],
             coef(modelo)[2], sebetas_teor[2],
             coef(modelo)[3], sebetas_teor[3],
             coef(modelo)[4], sebetas_teor[4]),
  
  Bootstrap = c(mean(betas[,1]), sdbeta1,
                mean(betas[,2]), sdbeta2,
                mean(betas[,3]), sdbeta3,
                mean(betas[,4]), sdbeta4)
)

num_cols = sapply(SDs1, is.numeric)
SDs1[num_cols] = round(SDs1[num_cols], 3)

num_cols = sapply(SDs2, is.numeric)
SDs2[num_cols] = round(SDs2[num_cols], 3)

SDs1
SDs2